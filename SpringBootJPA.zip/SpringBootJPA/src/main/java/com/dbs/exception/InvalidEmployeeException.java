package com.dbs.exception;

public class InvalidEmployeeException extends Exception {

	public InvalidEmployeeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidEmployeeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidEmployeeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidEmployeeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
 

	 

}
