package com.dbs.exception;

public class InvalidDepartmentException extends Exception {

	public InvalidDepartmentException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidDepartmentException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidDepartmentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidDepartmentException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}
